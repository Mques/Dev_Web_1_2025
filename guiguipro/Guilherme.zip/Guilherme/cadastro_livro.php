<?php
include_once("../service/livro-servico.php");

?>//ERRO. Faltou o sinal de interrogação de abertura do PHP no início do arquivo.
<html>
<body>
<?php
$livro = "";
if (isset($_GET["id"])) {
  $livro = Livro::pegarPorId($_GET["id"]);
}?>

<form name="formulárioLivro" action="executa-acao-livro.php" method="post">
  <input type="hidden" id="acao" name="acao" value="<?php echo empty($livro)? "alterar": "cadastrar";?>">
  <input type="hidden" id="id" name="id" value="<?php echo isset($livro)? $livro->id: "";?>">

  <label for="titulo">Título</label>
  <input id="titulo" value="<?php echo!empty($livro)? $livro->titulo: "";?>">

  <label for="autor">Autor</label>
  <input id="autor" value="<?php echo!empty($livro)? $livro->autor: "";?>">

  <label for="anoDePublic">Ano de publicação</label>
  <input id="anoDePublic" value="<?php echo!empty($livro)? $livro->anoDePublic: "";?>">

  <label for="quantidade">Quantidade</label>
  <input id="quantidade" value="<?php echo!empty($livro)? $livro->quantidade: "";?>">

  <button type="submit"><?php echo empty($livro)? "Alterar": "Cadastrar";?></button>
</form>
</body>
</html>