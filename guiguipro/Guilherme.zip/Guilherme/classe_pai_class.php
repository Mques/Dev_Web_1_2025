<?php
abstract class ClassePai {
  public $id;
  private $nomeArquivo;
  const Separador = "#";

  public function __construct($id, $nomeArquivo) {
    $this->id = $id;
    $this->nomeArquivo = $nomeArquivo;
  }

  abstract function montaLinhaDeDados();

  public function encontraUltimoId() {
    if (!isset($this->nomeArquivo)) {
      $this->id = 1;
      return;
    }
    $idTemp = 1;
    $arquivo = fopen($this->nomeArquivo, "r");
    while (!feof($arquivo)) {
      $linha = fgets($arquivo);
      if (empty($linha)) continue;
      $dados = explode(self::Separador, $linha);
      $idTemp = intval($dados) + 1;
    }
    fclose($arquivo);
    $this->codigo = $idTemp;
  }

  public function cadastrar() {
    //$this->encontraUltimoId; ERRO. Faltou os parênteses para chamar o método
    $this->encontraUltimoId();
    $arquivo = fopen($this->nomeArquivo, "a");
    fwrite($arquivo, $this->montaLinhaDeDados(). " \n");
    fclose($arquivo);
  }
  public function remover() {
    $arquivo = fopen($this->nomeArquivo, "r+");
    $aux = "";
    while (!feof($arquivo)) {
      $linha = fgets($arquivo);
      if (empty($linha)) continue;
      $dados = explode(self::Separador, $linha);
      if ($dados!= $this->id) $aux.= $linha;
    }
    truncate($arquivo, 0);
    rewind($arquivo);
    fwrite($arquivo, $aux);
    fclose($arquivo);
  }

  public function alterar() {
    $arquivo = fopen($this->nomeArquivo, "r+");
    $aux = "";
    while (!feof($arquivo)) {
      $linha = fgets($arquivo);
      if (empty($linha)) continue;
      $dados = explode(self::Separador, $linha);
      if ($dados == $this->id) $aux.= $this->montaLinhaDeDados(). "\n";
      else $aux.= $linha;
    }
    truncate($arquivo, 0);
    rewind($arquivo);
    fwrite($arquivo, $aux);
    fclose($arquivo);
  }
}
?>