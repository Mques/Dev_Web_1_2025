<?php
include_once("../service/livro-servico.php");
$acao = $_POST["acao"]?? $_GET["acao"]?? null;
$id = $_POST["id"]?? $_GET["id"]?? null;
$titulo = $_POST["titulo"]?? $_GET["titulo"]?? null;
$autor = $_POST["autor"]?? $_GET["autor"]?? null;
$anoDePublic = $_POST["ano"]?? $_GET["ano"]?? null;
$quantidade = $_POST["qtd"]?? $_GET["qtd"]?? null;

if ($acao == "cadastrar") {
    cadastrarLivro();
}

if ($acao == "alterar") {
    alterarLivro();
}

if ($acao == "remover") {
    removerLivro();
}
?>