<?php
include_once("classe-pai-class.php");
class Livro extends ClassePai {
    public $titulo;
    public $autor;
    public $anoDePublic;
    public $quantidade;

    public function __construct($titulo, $autor, $anoDePublic, $quantidade) {
        parent::__construct($id, $nomeArquivo);
        $this->titulo = $titulo;
        $this->autor = $autor;
        $this->anoDePublic = $anoDePublic;
        $this->quantidade = $quantidade;
    }
    //ERRO. COMO você está implementando um método abstrato, não deve usar a palavra 'function' antes do nome do método.
    function montaLinhaDados($id, $titulo, $autor, $anoDePublic, $quantidade) {
        return $this->id. self::Separador. $this->titulo. self::Separador. $this->autor. self::Separador. $this->anoDePublic. self::Separador. $this->quantidade;
    }

    public static function pegarPorId($id) {
        $arquivo = fopen("nomeDoArquivo", "r+");
        while (!feof($arquivo)) {
            $linha = fgets($arquivo);
            if (empty($linha)) continue;
            $dados = explode(self::Separador, $linha);
            if ($dados == $id) {
                fclose($arquivo);
                return new Livro($dados[0], $dados[1], $dados[2], $dados[3], $dados[4]);
            }
        }
        fclose($arquivo);
        return;
    }
    public static function filtrar($filtroNome) {
        $retorno = [];
        $arquivo = fopen("nomeDoArquivo", "r");
        while(!feof($arquivo)) {
            $linha = fgets($arquivo);
            if(empty($linha)) continue;
            $dados = explode(self::Separador, $linha);
            if(str_contains($dados, $filtroNome)) {
                array_push($retorno, new Livro($dados[0], $dados[1], $dados[2], $dados[3], $dados[4]));
            }
        }
        return $retorno;
        }
    }
?>