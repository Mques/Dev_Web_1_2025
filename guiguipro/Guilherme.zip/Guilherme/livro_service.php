<?php
include_once('../model/livro.class.php');

//public function cadastrarLivro($id, $titulo, $autor, $anoDePublic, $quantidade) {
//ERRO! Você não está dentro de uma classe. Portanto, não deve usar a palavra 'public function'.
function cadastrarLivro($id, $titulo, $autor, $anoDePublic, $quantidade) {
  $livro = new Livro(null, $titulo, $autor, $anoDePublic, $quantidade);
  $livro->cadastrar();
}

//public function livroPegarPorId($id) {
//ERRO! Você não está dentro de uma classe. Portanto, não deve usar a palavra 'public function'.
function livroPegarPorId($id) {
  $livro = Livro::pegarPorId($id);
}
// public function removerLivro($id) {
//ERRO! Você não está dentro de uma classe. Portanto, não deve usar a palavra 'public function'.
function removerLivro($id) {
  $livro = Livro::pegarPorId($id);
  if ($livro) {
    $livro->remover();
  }
}

//public function alterarLivro($id, $novoTitulo, $novoAutor, $novoAnoPublic, $novoQuantidade) {
//ERRO! Você não está dentro de uma classe. Portanto, não deve usar a palavra 'public function'.
function alterarLivro($id, $novoTitulo, $novoAutor, $novoAnoPublic, $novoQuantidade) {
  $livro = Livro::pegarPorId($id);
  if ($livro) {
    $livro->titulo = $novoTitulo;
    $livro->autor = $novoAutor;
    $livro->anoDePublic = $novoAnoPublic;
    $livro->quantidade = $novoQuantidade;
    $livro->alterar();
  }
}
//public function filtrarLivro($filtro) {
// ERRO! Você não está dentro de uma classe. Portanto, não deve usar a palavra 'public function'.
function filtrarLivro($filtro) {
  $livros = Livro::filtrar($filtro);
  echo "<table><tr><th>Título</th><th>Autor</th><th>Ano de publicação</th><th>Quantidade de exemplares</th></tr>";
  foreach ($livros as $livro) {
    echo "<tr>";
    echo "<td>". $livro->titulo. "</td>";
    echo "<td>". $livro->autor. "</td>";
    echo "<td>". $livro->anoDePublic. "</td>";
    echo "<td>". $livro->quantidade. "</td>";
    echo "<td><a href='cadastro-livro.php?id=". $livro->id. "'>Alterar</a></td>";
    echo "<td><a href='excluir-livro.php?acao=remover&id=". $livro->id. "'>Remover</a></td>";
    echo "</tr>";
  }
  echo "</table>";
}
//public function listaTudo() {
//ERRO! Você não está dentro de uma classe. Portanto, não deve usar a palavra 'public function'.
function listaTudo() {
  $livro = Livro::filtrar("");
}
?>

