<html>
<body>
  <form method="post">
    <label>Filtro</label>
    <input id="filtro" name="filtro">
    <button type="submit" id="botao">Filtro</button>
  </form>

  <?php
  
  //  include_once("../service/livro-servico.php");
  //Troquei para funcionar corretamente
  include_once("livro_service.php");
  $filtro = $_POST["filtro"];
  $botao = $_POST["botao"];

  if (isset($botao)) {
    //Livro::filtrarLivro($filtro);
    //ERRO. Você chama direto a função, não precisa usar o nome da classe.
    filtrarLivro($filtro);
  }?>
</body>
</html>
